import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Carrito here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Carrito extends Actor
{
    /**
     * Act - do whatever the Carrito wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    Boolean canFire =true;
    public Carrito(){
        setRotation(270);
        
    }
    
    public void act()
    {
        if(Greenfoot.isKeyDown("D")){
            setLocation(getX()+5, getY());
        }
        if(Greenfoot.isKeyDown("A")){
            setLocation(getX()-5, getY());
        }
        if(Greenfoot.isKeyDown("W")){
            setLocation(getX(), getY()-5);
        }
        if(Greenfoot.isKeyDown("S")){
            setLocation(getX(), getY()+5);
        }
        fireProjectile();
        // Add your action code here.
    }
    public void fireProjectile()
    {
        if(Greenfoot.isKeyDown("space") && canFire == true){
            getWorld().addObject(new Corazón(), getX(), getY()-30);
            canFire = false;
            
        } else if(!Greenfoot.isKeyDown("space")){
            canFire =true;   
        }

    }
}
